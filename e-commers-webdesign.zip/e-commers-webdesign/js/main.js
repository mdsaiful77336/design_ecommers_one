/*hide-menu section start===*/

/*------one-start----*/
$(document).ready(function(){
 
$("#pharma-1").mouseenter(function(){
    $("#pharma-show").show();
  });

    $("#pharma-show").mouseleave(function(){
      $("#pharma-show").hide();
    });

  $("#pharma-1").mouseenter(function(){
    $("#Hospital-show").hide();
  });

  $("#pharma-1").mouseenter(function(){
    $("#Food-show").hide();
  });
 $("#pharma-1").mouseenter(function(){
    $("#Machinery-show").hide();
  });
 $("#pharma-1").mouseenter(function(){
    $("#Supplies-show").hide();
  });
  $("#pharma-1").mouseenter(function(){
    $("#Electrical-show").hide();
  });


/*------one-end----*/
/*-------two-start----*/
$("#hospital-2").mouseenter(function(){
    $("#Hospital-show").show();
  });

    $("#Hospital-show").mouseleave(function(){
      $("#Hospital-show").hide();
    });

  $("#hospital-2").mouseenter(function(){
    $("#pharma-show").hide();
  });
  $("#hospital-2").mouseenter(function(){
    $("#Food-show").hide();
   });
 $("#hospital-2").mouseenter(function(){
    $("#Machinery-show").hide();
  });
 $("#hospital-2").mouseenter(function(){
    $("#Supplies-show").hide();
  });
  $("#hospital-2").mouseenter(function(){
    $("#Electrical-show").hide();
  });

/*-------two-end----*/
/*--------three-start-----*/
$("#food-3").mouseenter(function(){
    $("#Food-show").show();
  });

    $("#Food-show").mouseleave(function(){
      $("#Food-show").hide();
    });

  $("#food-3").mouseenter(function(){
    $("#pharma-show").hide();
  });
  $("#food-3").mouseenter(function(){
    $("#Hospital-show").hide();
 });
 $("#food-3").mouseenter(function(){
    $("#Machinery-show").hide();
  });
 $("#food-3").mouseenter(function(){
    $("#Supplies-show").hide();
  });
  $("#food-3").mouseenter(function(){
    $("#Electrical-show").hide();
  });

/*--------three-end-------*/
/*--------four-start-----*/
$("#Machinery-4").mouseenter(function(){
    $("#Machinery-show").show();
  });

    $("#Machinery-show").mouseleave(function(){
      $("#Machinery-show").hide();
    });

  $("#Machinery-4").mouseenter(function(){
    $("#pharma-show").hide();
  });
  $("#Machinery-4").mouseenter(function(){
    $("#Hospital-show").hide();
 });
 $("#Machinery-4").mouseenter(function(){
    $("#Food-show").hide();
  });
 $("#Machinery-4").mouseenter(function(){
    $("#Supplies-show").hide();
  });
  $("#Machinery-4").mouseenter(function(){
    $("#Electrical-show").hide();
  });

/*--------four-end-------*/
/*--------five-start-----*/
$("#Supplies-5").mouseenter(function(){
    $("#Supplies-show").show();
  });

    $("#Supplies-show").mouseleave(function(){
      $("#Supplies-show").hide();
    });

  $("#Supplies-5").mouseenter(function(){
    $("#pharma-show").hide();
  });
  $("#Supplies-5").mouseenter(function(){
    $("#Hospital-show").hide();
 });
 $("#Supplies-5").mouseenter(function(){
    $("#Food-show").hide();
  });
 $("#Supplies-5").mouseenter(function(){
    $("#Machinery-show").hide();
  });
  $("#Supplies-5").mouseenter(function(){
    $("#Electrical-show").hide();
  });

/*--------five-end-------*/

/*--------six-start-----*/
$("#Electronics-6").mouseenter(function(){
    $("#Electrical-show").show();
  });

    $("#Electrical-show").mouseleave(function(){
      $("#Electrical-show").hide();
    });

  $("#Electronics-6").mouseenter(function(){
    $("#pharma-show").hide();
  });
  $("#Electronics-6").mouseenter(function(){
    $("#Hospital-show").hide();
 });
 $("#Electronics-6").mouseenter(function(){
    $("#Food-show").hide();
  });
 $("#Electronics-6").mouseenter(function(){
    $("#Supplies-show").hide();
  });
  $("#Electronics-6").mouseenter(function(){
    $("#Machinery-show").hide();
  });

/*--------six-end-------*/
  });
 
/*hide-menu section -- End===*/

 /*===========scroll-up-section=====*/
 $(document).ready(function(){

   $(window).scroll(function(){
    if ($(this).scrollTop()>400){
      $(".goto-scroll-up").fadeIn();
    }
    else{ $(".goto-scroll-up").fadeOut();

    }
   });
      $(".goto-scroll-up").click(function(){
        $("html,body").animate({scrollTop:0},500);
      })
 });




 /* Customers happy section----*/
 $(document).ready(function(){

$("#cs-1").click(function(){
    $("#csv-1").show();
  });

  $("#cs-1").click(function(){
    $("#csv-2").hide();
  });

  $("#cs-1").click(function(){
    $("#csv-3").hide();
  });
 $("#cs-1").click(function(){
    $("#csv-4").hide();
  });
 $("#cs-1").click(function(){
    $("#csv-5").hide();
  });
 

$("#cs-2").click(function(){
    $("#csv-2").show();
  });

  $("#cs-2").click(function(){
    $("#csv-1").hide();
  });

  $("#cs-2").click(function(){
    $("#csv-3").hide();
  });
 $("#cs-2").click(function(){
    $("#csv-4").hide();
  });
 $("#cs-2").click(function(){
    $("#csv-5").hide();
  });
 


 $("#cs-3").click(function(){
    $("#csv-3").show();
  });

  $("#cs-3").click(function(){
    $("#csv-1").hide();
  });

  $("#cs-3").click(function(){
    $("#csv-2").hide();
  });
 $("#cs-3").click(function(){
    $("#csv-4").hide();
  });
 $("#cs-3").click(function(){
    $("#csv-5").hide();
  });

 $("#cs-4").click(function(){
    $("#csv-4").show();
  });

  $("#cs-4").click(function(){
    $("#csv-1").hide();
  });

  $("#cs-4").click(function(){
    $("#csv-2").hide();
  });
 $("#cs-4").click(function(){
    $("#csv-3").hide();
  });
 $("#cs-4").click(function(){
    $("#csv-5").hide();
  });


 $("#cs-5").click(function(){
    $("#csv-5").show();
  });

  $("#cs-5").click(function(){
    $("#csv-1").hide();
  });

  $("#cs-5").click(function(){
    $("#csv-2").hide();
  });
 $("#cs-5").click(function(){
    $("#csv-3").hide();
  });
 $("#cs-5").click(function(){
    $("#csv-4").hide();
  });
 });